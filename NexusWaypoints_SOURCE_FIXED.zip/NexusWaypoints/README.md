# Nexus Waypoints — Levi Pack source project

Versão do mod: **1.0.0**  
Alvo de compilação: **Minecraft Bedrock Android 1.26.60.x / ARM64**  
Loader: **LeviLauncher Android / Preloader SDK 0.2.2**

## O que esta versão implementa

- Salvar a posição atual como waypoint, com nome e cor.
- Guardar até 64 waypoints no diretório `data/waypoints.json` do mod.
- Carregar os waypoints novamente quando o mod for iniciado.
- Navegar entre waypoints, anterior/próximo e excluir o selecionado.
- HUD 2D com nome, distância horizontal, coordenadas e direção relativa (frente/esquerda/direita/atrás).
- Indicação simples de destino acima/abaixo.
- Botões no Mod Menu do LeviLauncher e configurações de nome, cor e exibição do HUD.

## Dependência obrigatória

Esta primeira versão usa a API pública de runtime do **BedrockTools** para receber posição/rotação do jogador. O workflow já compila uma cópia ARM64 do BedrockTools a partir do commit `81176f287453b68c131a34f78b198355675bd7b6`, que contém o suporte a Minecraft 1.26.60, e inclui o respectivo `.levipack` na mesma entrega. Instale o pacote `BedrockTools_1.26.60_ARM64.levipack` primeiro e depois o `NexusWaypoints_1.0.0_ARM64.levipack`.

A integração usa o ABI v1 exportado por `BedrockTools_GetApi`, eventos `Frame` e `LocalPlayerTick` e os offsets públicos do componente de posição/rotação no perfil 1.26.60. O código procura a biblioteca já carregada (`RTLD_NOLOAD`); não injeta nem altera a biblioteca de outro mod.

## Limitação visual importante

O HUD desta versão é **2D na tela** (bússola direcional, nome, distância e coordenadas). Ainda não há feixe/ícone 3D renderizado no terreno como alguns mods Java. A API pública do Mod Menu usada aqui fornece desenho de overlay 2D; o render 3D no mundo exige outra integração de renderização, que não foi validada para este alvo.

Waypoints são armazenados por coordenadas X/Y/Z, sem separação automática por dimensão ou por mundo. Evite misturar arquivos de dados ao copiar uma instalação para outro mundo.

## Como gerar o `.levipack` usando GitHub Actions pelo celular

1. Crie um repositório GitHub vazio e envie **todo o conteúdo desta pasta** (incluindo `.github/workflows/build.yml`).
2. Abra a aba **Actions** do repositório.
3. Selecione **Build Nexus Waypoints Levi Pack** e toque em **Run workflow**.
4. Quando terminar, abra a execução e baixe o artifact **NexusWaypoints-1.0.0-and-runtime-ARM64**.
5. Extraia o ZIP do artifact. Ele terá dois pacotes: `dependencies/BedrockTools_1.26.60_ARM64.levipack` e `NexusWaypoints_1.0.0_ARM64.levipack`.
6. Importe e habilite **BedrockTools primeiro**; depois importe e habilite **Nexus Waypoints** no LeviLauncher.

O workflow compila o BedrockTools e o Nexus Waypoints com Android NDK r28c para ARM64, gera os dois `.levipack` e testa a integridade dos pacotes.

## Teste local da matemática (opcional)

Em um ambiente com `g++`:

```sh
g++ -std=c++20 -Wall -Wextra -pedantic tests/waypoint_math_test.cpp -o waypoint_math_test
./waypoint_math_test
```

## Fontes técnicas

- LeviLauncher Android Native Mod Quick Start: https://docs.levimc.org/LeviLaunchroid/guide/build
- LeviLauncher Mod API: https://docs.levimc.org/LeviLaunchroid/api/mod
- BedrockTools (código e cabeçalhos públicos): https://github.com/QYCottage/BedrockTools

## Licença do código deste projeto

MIT. Os projetos externos citados acima mantêm suas próprias licenças e não são incluídos neste pacote-fonte.
