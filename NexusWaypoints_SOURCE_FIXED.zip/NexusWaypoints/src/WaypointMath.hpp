#pragma once
#include <cmath>
#include <string_view>

namespace nexus::math {
inline float normalizeDegrees(float value) noexcept {
    while (value > 180.0f) value -= 360.0f;
    while (value < -180.0f) value += 360.0f;
    return value;
}

inline float horizontalDistance(float x1, float z1, float x2, float z2) noexcept {
    const float dx = x2 - x1;
    const float dz = z2 - z1;
    return std::sqrt(dx * dx + dz * dz);
}

// Bedrock yaw 0 faces south. This produces the target bearing in the same convention.
inline float targetYaw(float playerX, float playerZ, float targetX, float targetZ) noexcept {
    constexpr float radToDeg = 57.29577951308232f;
    const float dx = targetX - playerX;
    const float dz = targetZ - playerZ;
    return std::atan2(-dx, dz) * radToDeg;
}

inline float relativeBearing(float playerYaw, float playerX, float playerZ,
                             float targetX, float targetZ) noexcept {
    return normalizeDegrees(targetYaw(playerX, playerZ, targetX, targetZ) - playerYaw);
}

inline std::string_view directionLabel(float delta) noexcept {
    const float a = std::fabs(normalizeDegrees(delta));
    if (a >= 157.5f) return "ATRAS";
    if (a <= 22.5f) return "FRENTE";
    return delta > 0.0f ? "DIREITA" : "ESQUERDA";
}
} // namespace nexus::math
