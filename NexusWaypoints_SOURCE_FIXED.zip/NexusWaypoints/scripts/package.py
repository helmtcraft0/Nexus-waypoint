#!/usr/bin/env python3
import argparse
import json
import pathlib
import zipfile


def main() -> None:
    parser = argparse.ArgumentParser(description="Package Nexus Waypoints as a Levi Pack")
    parser.add_argument("--library", required=True, type=pathlib.Path)
    parser.add_argument("--output", required=True, type=pathlib.Path)
    parser.add_argument("--project", default=pathlib.Path(__file__).resolve().parents[1], type=pathlib.Path)
    args = parser.parse_args()

    root = args.project.resolve()
    library = args.library.resolve()
    if not library.is_file():
        raise SystemExit(f"Native library not found: {library}")
    if library.read_bytes()[:4] != b"\x7fELF":
        raise SystemExit("The build output is not an ELF shared library")
    manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    if manifest.get("type") != "preload-native" or manifest.get("entry") != "libnexus_waypoints.so":
        raise SystemExit("Unexpected Levi manifest configuration")

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        archive.write(root / "manifest.json", "manifest.json")
        archive.write(root / "icon.png", "icon.png")
        archive.write(library, manifest["entry"])
        notice = root / "THIRD_PARTY_NOTICES.txt"
        if notice.exists():
            archive.write(notice, "THIRD_PARTY_NOTICES.txt")

    with zipfile.ZipFile(args.output, "r") as archive:
        bad = archive.testzip()
        if bad:
            raise SystemExit(f"ZIP integrity check failed at {bad}")
        names = set(archive.namelist())
        required = {"manifest.json", "icon.png", manifest["entry"]}
        if not required.issubset(names):
            raise SystemExit("Package is missing required files")
    print(f"Created {args.output} ({args.output.stat().st_size} bytes)")


if __name__ == "__main__":
    main()
