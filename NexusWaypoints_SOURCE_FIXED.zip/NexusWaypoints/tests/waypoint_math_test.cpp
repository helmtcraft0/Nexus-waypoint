#include "../src/WaypointMath.hpp"
#include <cassert>
#include <cmath>

int main() {
    assert(std::fabs(nexus::math::horizontalDistance(0, 0, 3, 4) - 5.0f) < 0.001f);
    assert(std::fabs(nexus::math::normalizeDegrees(190.0f) + 170.0f) < 0.001f);
    assert(nexus::math::directionLabel(0.0f) == "FRENTE");
    assert(nexus::math::directionLabel(90.0f) == "DIREITA");
    assert(nexus::math::directionLabel(-90.0f) == "ESQUERDA");
    assert(nexus::math::directionLabel(180.0f) == "ATRAS");
    assert(std::fabs(nexus::math::relativeBearing(0, 0, 0, 0, 10) - 0.0f) < 0.001f);
    return 0;
}
