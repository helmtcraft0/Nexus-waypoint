#include <pl/Mod.hpp>
#include <pl/ModMenu.hpp>

#include "WaypointMath.hpp"

#include <algorithm>
#include <array>
#include <atomic>
#include <exception>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <dlfcn.h>
#include <filesystem>
#include <fstream>
#include <mutex>
#include <string>
#include <string_view>
#include <vector>

#include <nlohmann/json.hpp>

// Exact public event/API declarations from BedrockTools ABI v1. Keeping the
// signatures identical avoids calling the runtime through incompatible enum types.
namespace bedrocktools::events {
enum class EventType : std::uint32_t {
    Frame = 1, LocalPlayerTick, ClientInstanceUpdate, Attack, MouseInput,
    ScreenState, LocalPlayerPreTick, GameModeAction, ContainerSlotSelected
};
enum class EventPriority : std::int32_t { First = 200, Early = 100, Normal = 0, Late = -100, Last = -200 };
}
namespace bedrocktools::sdk { class ClientInstance; }
namespace bedrocktools::api {
using EventCallback = void (*)(events::EventType, void*, void*);
struct ApiV1 {
    std::uint32_t abiVersion;
    std::uint32_t structSize;
    std::uintptr_t (*resolveSignature)(std::uint16_t);
    sdk::ClientInstance* (*clientInstance)();
    std::uint64_t (*subscribe)(events::EventType, events::EventPriority, EventCallback, void*);
    void (*unsubscribe)(std::uint64_t);
};
using GetApiFunction = const ApiV1* (*)(std::uint32_t);
}

namespace {
using json = nlohmann::json;
using RuntimeEvent = bedrocktools::events::EventType;
using RuntimePriority = bedrocktools::events::EventPriority;
using RuntimeApiV1 = bedrocktools::api::ApiV1;
using GetRuntimeApi = bedrocktools::api::GetApiFunction;

struct Vec2 { float x{}, y{}; };
struct Vec3 { float x{}, y{}, z{}; };
struct PlayerTickPayload { void* player{}; };

constexpr std::size_t kStateVectorComponentOffset = 0x228;
constexpr std::size_t kActorRotationComponentOffset = 0x238;
constexpr std::size_t kMaxWaypoints = 64;
constexpr const char* kModuleId = "nexus_waypoints.hud";
constexpr const char* kSaveButtonId = "nexus_waypoints.save";
constexpr const char* kNextButtonId = "nexus_waypoints.next";
constexpr const char* kPrevButtonId = "nexus_waypoints.prev";
constexpr const char* kDeleteButtonId = "nexus_waypoints.delete";
constexpr const char* kNameConfigKey = "waypointName";
constexpr const char* kColorConfigKey = "waypointColor";
constexpr const char* kHudConfigKey = "showHud";

struct Waypoint {
    std::string name;
    float x{}, y{}, z{};
    std::string color{"Purple"};
};

struct PlayerSnapshot {
    Vec3 position{};
    Vec2 rotation{};
    bool valid{false};
};

template <typename T>
bool readAt(const void* base, std::size_t offset, T& value) noexcept {
    if (!base) return false;
    std::memcpy(&value, static_cast<const std::byte*>(base) + offset, sizeof(T));
    return true;
}

std::uint32_t accentFor(std::string_view color) {
    if (color == "Blue") return 0xFF67C7FFU;
    if (color == "Green") return 0xFF66E0A3U;
    if (color == "Gold") return 0xFFFFC66DU;
    return 0xFFB89AFFU;
}

std::string cleanName(std::string value) {
    if (value.size() > 32) value.resize(32);
    for (char& c : value) {
        const unsigned char u = static_cast<unsigned char>(c);
        if (u < 0x20 || c == '\n' || c == '\r') c = ' ';
    }
    if (value.find_first_not_of(" \t") == std::string::npos) value = "Waypoint";
    return value;
}

class NexusWaypoints {
public:
    static NexusWaypoints& instance() {
        static NexusWaypoints mod;
        return mod;
    }

    bool load() {
        mSelf = pl::mod::NativeMod::current();
        if (!mSelf) return false;
        try {
            std::filesystem::create_directories(mSelf->getDataDir());
            loadWaypoints();
            mSelf->getLogger().info("Nexus Waypoints 1.0.0 loaded");
            return true;
        } catch (const std::exception& e) {
            mSelf->getLogger().error("Could not load waypoint data: {}", e.what());
            return false;
        }
    }

    bool enable() {
        if (!mSelf) return false;
        mActive.store(true, std::memory_order_release);
        registerUi();
        if (!connectRuntime()) {
            mSelf->getLogger().warn(
                "BedrockTools runtime not found. Install and enable BedrockTools 1.5.10 for Minecraft 1.26.60; waypoint buttons will be waiting for the runtime.");
        }
        return true;
    }

    bool disable() {
        mActive.store(false, std::memory_order_release);
        saveWaypoints();
        disconnectRuntime();
        unregisterUi();
        clearOverlay();
        return true;
    }

    bool unload() {
        mActive.store(false, std::memory_order_release);
        saveWaypoints();
        disconnectRuntime();
        unregisterUi();
        clearOverlay();
        return true;
    }

private:
    pl::mod::NativeMod* mSelf{};
    void* mRuntimeHandle{};
    const RuntimeApiV1* mApi{};
    std::uint64_t mFrameSubscription{};
    std::uint64_t mPlayerSubscription{};
    std::mutex mMutex;
    PlayerSnapshot mPlayer;
    std::vector<Waypoint> mWaypoints;
    std::size_t mSelected{};
    std::string mPendingName{"Minha Casa"};
    std::string mPendingColor{"Purple"};
    bool mShowHud{true};
    std::atomic_bool mActive{true};

    static void runtimeCallback(RuntimeEvent event, void* payload, void* userData) {
        auto* self = static_cast<NexusWaypoints*>(userData);
        if (!self || !self->mActive.load(std::memory_order_acquire)) return;
        if (event == RuntimeEvent::LocalPlayerTick) {
            const auto* tick = static_cast<const PlayerTickPayload*>(payload);
            if (tick && tick->player) self->updatePlayer(tick->player);
        } else if (event == RuntimeEvent::Frame) {
            self->drawOverlay();
        }
    }

    static void toggleCallback(std::string_view moduleId, bool enabled) {
        if (moduleId != kModuleId) return;
        auto& self = instance();
        self.mActive.store(enabled, std::memory_order_release);
        if (!enabled) self.clearOverlay();
    }

    static void configCallback(std::string_view moduleId, std::string_view key,
                               std::string_view value) {
        if (moduleId != kModuleId) return;
        auto& self = instance();
        std::lock_guard lock(self.mMutex);
        if (key == kNameConfigKey) {
            self.mPendingName = cleanName(std::string(value));
        } else if (key == kColorConfigKey) {
            if (value == "Purple" || value == "Blue" || value == "Green" || value == "Gold")
                self.mPendingColor = std::string(value);
        } else if (key == kHudConfigKey) {
            self.mShowHud = value == "true" || value == "1" || value == "on";
        }
    }

    static void buttonCallback(std::string_view buttonId,
                               pl::modmenu::ButtonEvent event, float) {
        if (event != pl::modmenu::ButtonEvent::Click) return;
        auto& self = instance();
        if (!self.mActive.load(std::memory_order_acquire)) return;
        if (!self.mApi && !self.connectRuntime()) {
            if (self.mSelf) self.mSelf->getLogger().warn("Waypoint runtime is unavailable. Enable the matching BedrockTools build first.");
            return;
        }
        if (buttonId == kSaveButtonId) self.addWaypoint();
        else if (buttonId == kNextButtonId) self.changeSelection(1);
        else if (buttonId == kPrevButtonId) self.changeSelection(-1);
        else if (buttonId == kDeleteButtonId) self.deleteSelected();
    }

    bool connectRuntime() {
        if (mApi && mFrameSubscription && mPlayerSubscription) return true;
        mRuntimeHandle = dlopen("libBedrockTools.so", RTLD_NOW | RTLD_NOLOAD);
        if (!mRuntimeHandle) return false;
        auto getter = reinterpret_cast<GetRuntimeApi>(dlsym(mRuntimeHandle, "BedrockTools_GetApi"));
        if (!getter) {
            dlclose(mRuntimeHandle);
            mRuntimeHandle = nullptr;
            return false;
        }
        mApi = getter(1);
        if (!mApi || mApi->abiVersion != 1 || mApi->structSize < sizeof(RuntimeApiV1) ||
            !mApi->subscribe || !mApi->unsubscribe) {
            mApi = nullptr;
            dlclose(mRuntimeHandle);
            mRuntimeHandle = nullptr;
            return false;
        }
        mFrameSubscription = mApi->subscribe(RuntimeEvent::Frame, RuntimePriority::Normal,
                                             runtimeCallback, this);
        mPlayerSubscription = mApi->subscribe(RuntimeEvent::LocalPlayerTick, RuntimePriority::Normal,
                                              runtimeCallback, this);
        if (!mFrameSubscription || !mPlayerSubscription) {
            disconnectRuntime();
            return false;
        }
        mSelf->getLogger().info("Connected to BedrockTools runtime ABI v1");
        return true;
    }

    void disconnectRuntime() {
        if (mApi) {
            if (mFrameSubscription) mApi->unsubscribe(mFrameSubscription);
            if (mPlayerSubscription) mApi->unsubscribe(mPlayerSubscription);
        }
        mFrameSubscription = 0;
        mPlayerSubscription = 0;
        mApi = nullptr;
        if (mRuntimeHandle) dlclose(mRuntimeHandle);
        mRuntimeHandle = nullptr;
    }

    void registerUi() {
        using namespace pl::modmenu;
        ModuleBuilder(kModuleId, "Nexus Waypoints")
            .modId(mSelf->getId())
            .description("Salve locais e acompanhe a direcao e distancia no HUD.")
            .defaultEnabled(true)
            .onToggle(toggleCallback)
            .config(kNameConfigKey, "Nome do proximo waypoint", ConfigType::Radio, "Minha Casa",
                    "Minha Casa,Base,Portal,Fazenda,Mina")
            .config(kColorConfigKey, "Cor do waypoint", ConfigType::Radio, "Purple",
                    "Purple,Blue,Green,Gold")
            .config(kHudConfigKey, "Mostrar HUD", ConfigType::Toggle, "true")
            .onConfigChanged(configCallback)
            .registerModule();

        registerButton(kSaveButtonId, "Salvar posição", "SALVAR");
        registerButton(kPrevButtonId, "Waypoint anterior", "ANTERIOR");
        registerButton(kNextButtonId, "Proximo waypoint", "PROXIMO");
        registerButton(kDeleteButtonId, "Excluir waypoint", "EXCLUIR");
    }

    void registerButton(const char* id, const char* name, const char* label) {
        (void)pl::modmenu::ButtonBuilder(id, name)
            .moduleId(kModuleId)
            .modId(mSelf->getId())
            .label(label)
            .behavior(pl::modmenu::ButtonBehavior::Click)
            .stylePreset(pl::modmenu::ButtonStylePreset::Accent)
            .styleColors(0xCC211A30U, 0xFF9C78F0U, 0xFFB89AFFU)
            .textColor(0xFFFFFFFFU)
            .activeTextColor(0xFF151020U)
            .onEvent(buttonCallback)
            .registerButton();
    }

    void unregisterUi() {
        pl::modmenu::unregisterButton(kSaveButtonId);
        pl::modmenu::unregisterButton(kPrevButtonId);
        pl::modmenu::unregisterButton(kNextButtonId);
        pl::modmenu::unregisterButton(kDeleteButtonId);
        pl::modmenu::unregisterModule(kModuleId);
    }

    void updatePlayer(void* player) {
        void* stateComponent{};
        void* rotationComponent{};
        Vec3 pos{};
        Vec2 rot{};
        if (!readAt(player, kStateVectorComponentOffset, stateComponent) ||
            !readAt(player, kActorRotationComponentOffset, rotationComponent) ||
            !stateComponent || !rotationComponent ||
            !readAt(stateComponent, 0, pos) || !readAt(rotationComponent, 0, rot) ||
            !std::isfinite(pos.x) || !std::isfinite(pos.y) || !std::isfinite(pos.z) ||
            !std::isfinite(rot.y)) return;
        std::lock_guard lock(mMutex);
        mPlayer = {pos, rot, true};
    }

    void addWaypoint() {
        PlayerSnapshot player;
        std::string name;
        std::string color;
        {
            std::lock_guard lock(mMutex);
            player = mPlayer;
            name = cleanName(mPendingName);
            color = mPendingColor;
            if (!player.valid) {
                mSelf->getLogger().warn("Player position is not ready yet; wait a moment and press Save again.");
                return;
            }
            if (mWaypoints.size() >= kMaxWaypoints) {
                mSelf->getLogger().warn("Waypoint limit reached ({})", kMaxWaypoints);
                return;
            }
            mWaypoints.push_back({name, std::round(player.position.x), std::round(player.position.y),
                                  std::round(player.position.z), color});
            mSelected = mWaypoints.size() - 1;
        }
        saveWaypoints();
        mSelf->getLogger().info("Saved waypoint {}", name);
    }

    void changeSelection(int direction) {
        std::lock_guard lock(mMutex);
        if (mWaypoints.empty()) return;
        const auto count = static_cast<long long>(mWaypoints.size());
        auto next = static_cast<long long>(mSelected) + direction;
        next = (next % count + count) % count;
        mSelected = static_cast<std::size_t>(next);
    }

    void deleteSelected() {
        {
            std::lock_guard lock(mMutex);
            if (mWaypoints.empty() || mSelected >= mWaypoints.size()) return;
            mWaypoints.erase(mWaypoints.begin() + static_cast<std::ptrdiff_t>(mSelected));
            if (!mWaypoints.empty() && mSelected >= mWaypoints.size()) mSelected = mWaypoints.size() - 1;
            else if (mWaypoints.empty()) mSelected = 0;
        }
        saveWaypoints();
    }

    void loadWaypoints() {
        const auto path = mSelf->getDataDir() / "waypoints.json";
        if (!std::filesystem::exists(path)) return;
        std::ifstream input(path);
        if (!input) return;
        json doc = json::parse(input, nullptr, false);
        if (!doc.is_object() || !doc.contains("waypoints") || !doc["waypoints"].is_array()) return;
        std::lock_guard lock(mMutex);
        for (const auto& item : doc["waypoints"]) {
            if (mWaypoints.size() >= kMaxWaypoints || !item.is_object()) break;
            if (!item.contains("name") || !item.contains("x") || !item.contains("y") || !item.contains("z")) continue;
            try {
                Waypoint point;
                point.name = cleanName(item.at("name").get<std::string>());
                point.x = item.at("x").get<float>();
                point.y = item.at("y").get<float>();
                point.z = item.at("z").get<float>();
                if (item.contains("color")) point.color = item.at("color").get<std::string>();
                if (point.color != "Purple" && point.color != "Blue" && point.color != "Green" && point.color != "Gold") point.color = "Purple";
                if (!std::isfinite(point.x) || !std::isfinite(point.y) || !std::isfinite(point.z)) continue;
                mWaypoints.push_back(std::move(point));
            } catch (...) { /* Ignore malformed entries without losing valid waypoints. */ }
        }
        if (!mWaypoints.empty()) mSelected = 0;
    }

    void saveWaypoints() {
        if (!mSelf) return;
        json doc;
        {
            std::lock_guard lock(mMutex);
            doc["format"] = 1;
            doc["waypoints"] = json::array();
            for (const auto& p : mWaypoints) {
                doc["waypoints"].push_back({{"name", p.name}, {"x", p.x}, {"y", p.y},
                                             {"z", p.z}, {"color", p.color}});
            }
        }
        try {
            std::filesystem::create_directories(mSelf->getDataDir());
            const auto finalPath = mSelf->getDataDir() / "waypoints.json";
            const auto tempPath = mSelf->getDataDir() / "waypoints.json.tmp";
            std::ofstream output(tempPath, std::ios::binary | std::ios::trunc);
            if (!output) return;
            output << doc.dump(2);
            output.close();
            std::error_code ec;
            std::filesystem::rename(tempPath, finalPath, ec);
            if (ec) {
                std::filesystem::remove(finalPath, ec);
                ec.clear();
                std::filesystem::rename(tempPath, finalPath, ec);
            }
        } catch (const std::exception& e) {
            mSelf->getLogger().warn("Could not persist waypoints: {}", e.what());
        }
    }

    void drawOverlay() {
        PlayerSnapshot player;
        std::vector<Waypoint> points;
        std::size_t selected{};
        bool show{};
        {
            std::lock_guard lock(mMutex);
            player = mPlayer;
            points = mWaypoints;
            selected = mSelected;
            show = mShowHud;
        }
        if (!mActive.load(std::memory_order_acquire) || !show || !player.valid || points.empty() || selected >= points.size()) {
            clearOverlay();
            return;
        }

        const auto& target = points[selected];
        const float distance = nexus::math::horizontalDistance(player.position.x, player.position.z, target.x, target.z);
        const float delta = nexus::math::relativeBearing(player.rotation.y, player.position.x,
                                                         player.position.z, target.x, target.z);
        const auto direction = nexus::math::directionLabel(delta);
        const int dy = static_cast<int>(std::round(target.y - player.position.y));
        const std::uint32_t accent = accentFor(target.color);

        std::vector<pl::modmenu::DrawCommand> commands;
        auto rect = [&](pl::modmenu::DrawCommandType type, float x, float y, float w,
                        float h, std::uint32_t color, float size = 0.0f) {
            pl::modmenu::DrawCommand cmd{};
            cmd.type = type; cmd.x = x; cmd.y = y; cmd.w = w; cmd.h = h;
            cmd.color = color; cmd.size = size; commands.push_back(std::move(cmd));
        };
        auto text = [&](std::string value, float x, float y, float size, std::uint32_t color) {
            pl::modmenu::DrawCommand cmd{};
            cmd.type = pl::modmenu::DrawCommandType::Text;
            cmd.x = x; cmd.y = y; cmd.w = 1.0f; cmd.h = 1.0f;
            cmd.color = color; cmd.size = size; cmd.text = std::move(value);
            commands.push_back(std::move(cmd));
        };

        rect(pl::modmenu::DrawCommandType::RectFilled, 18.0f, 112.0f, 306.0f, 112.0f, 0xD9121020U);
        rect(pl::modmenu::DrawCommandType::Rect, 18.0f, 112.0f, 306.0f, 112.0f, accent, 1.5f);
        text("NEXUS WAYPOINT", 30.0f, 121.0f, 16.0f, accent);
        text(target.name, 30.0f, 145.0f, 18.0f, 0xFFFFFFFFU);
        text(std::string(direction) + "  " + std::to_string(static_cast<int>(std::round(distance))) + " m",
             30.0f, 171.0f, 16.0f, 0xFFF1EAFE);
        text("X " + std::to_string(static_cast<int>(std::round(target.x))) +
             "   Y " + std::to_string(static_cast<int>(std::round(target.y))) +
             "   Z " + std::to_string(static_cast<int>(std::round(target.z))),
             30.0f, 198.0f, 13.0f, 0xFFBDB5CDU);
        if (std::abs(dy) >= 2) {
            text(dy > 0 ? "DESTINO ACIMA" : "DESTINO ABAIXO", 220.0f, 171.0f, 11.0f, accent);
        }
        const std::string counter = std::to_string(selected + 1) + "/" + std::to_string(points.size());
        text(counter, 280.0f, 121.0f, 11.0f, 0xFFBDB5CDU);
        pl::modmenu::submitDrawCommands(kModuleId, commands);
    }

    void clearOverlay() {
        pl::modmenu::submitDrawCommands(kModuleId, {});
    }
};

} // namespace

PL_REGISTER_MOD(NexusWaypoints, NexusWaypoints::instance())
